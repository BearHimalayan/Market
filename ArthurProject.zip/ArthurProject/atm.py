class ATM:

    pass