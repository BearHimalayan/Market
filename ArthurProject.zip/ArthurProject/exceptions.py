class ProductNotFound(Exception):
    pass


class NotEnoughMoney(Exception):
    pass 